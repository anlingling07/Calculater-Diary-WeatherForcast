package com.example.allprojects.Diary;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;


public class Diary extends AppCompatActivity {
    private Button mButton;
    private ListView mList;
    private Intent mIntent;
    private MyAdapter mAdapter;
    private SqlHelper sqlHelper;
    private Cursor cursor;
    private SQLiteDatabase dbreader;
    private Button but_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.allprojects.R.layout.diary_main);//切换显示View
        mList = (ListView) this.findViewById(com.example.allprojects.R.id.list);
        sqlHelper = new SqlHelper(this);
        dbreader = sqlHelper.getReadableDatabase();

        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("Range")
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                cursor.moveToPosition(i);
                //把想要传递的数据暂存在intent中，当另一个活动启动后，把这些数据从intent缓存中取出即可
                Intent intent = new Intent(Diary.this,ShowDiary.class);
                intent.putExtra(sqlHelper.TITLE,cursor.getString(cursor.getColumnIndex(sqlHelper.TITLE)));
                intent.putExtra(sqlHelper.AUTHOR,cursor.getString(cursor.getColumnIndex(sqlHelper.AUTHOR)));
                intent.putExtra(sqlHelper.ID,cursor.getInt(cursor.getColumnIndex(sqlHelper.ID)));
                intent.putExtra(sqlHelper.CONTENT,cursor.getString(cursor.getColumnIndex(sqlHelper.CONTENT)));
                intent.putExtra(sqlHelper.TIME,cursor.getString(cursor.getColumnIndex(sqlHelper.TIME)));
                startActivity(intent);
            }
        });
    }

    public void add(View v) {
        mIntent = new Intent(Diary.this,AddDIary.class);
        startActivity(mIntent);
    }

    public void selectDb() {
        cursor = dbreader.query
                (sqlHelper.TABLE_NAME,null,null,null,null,null,null);
        mAdapter = new MyAdapter(this,cursor);
        mList.setAdapter(mAdapter);
    }


    /*
    * Activity第一次创建时 重新加载实例时调用
    * */
    @Override
    protected void onResume() {
        super.onResume();
        selectDb();
    }
}