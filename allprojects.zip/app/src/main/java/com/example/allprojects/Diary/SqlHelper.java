package com.example.allprojects.Diary;




import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SqlHelper extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "notes";
    public static final String CONTENT = "content";
    public static final String ID = "_id";
    public static  final String AUTHOR = "author";
    public static  final String TITLE = "title";
    public static final String TIME = "time";

    public SqlHelper(Context context) {
        super(context, "notes", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql;
        sql = "create table notes ( _id integer primary key AUTOINCREMENT, content TEXT NOT NULL, author TEXT NOT NULL,title TEXT NOT NULL,time TEXT NOT NULL )";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}