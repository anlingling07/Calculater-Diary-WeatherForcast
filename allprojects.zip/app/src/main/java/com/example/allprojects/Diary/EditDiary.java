/*package com.example.allprojects.Diary;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.allprojects.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EditDiary extends AppCompatActivity {
    private EditText mEt;
    private EditText titleEt;
    private EditText authorEt;
    private SqlHelper mDb;
    private SQLiteDatabase mSqldb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary_edit);
        mEt = (EditText) this.findViewById(R.id.ed_text);
        titleEt=(EditText)this.findViewById(R.id.ed_title);
        authorEt=(EditText)this.findViewById(R.id.ed_author);
        mDb = new SqlHelper(this);
        mSqldb = mDb.getWritableDatabase();
    }
    public void savenew(View v) {

        DbAdd();
        finish();
    }
    public void canclenew(View v) {
        finish();
    }
    public void DbAdd() {
        //将基础数据存储在cv中
        ContentValues cv = new ContentValues();
        cv.put(SqlHelper.TITLE,titleEt.getText().toString());
        cv.put(SqlHelper.TIME,getTime());
        cv.put(SqlHelper.CONTENT,mEt.getText().toString());
        cv.put(SqlHelper.AUTHOR,authorEt.getText().toString());
        mSqldb.update(SqlHelper.TABLE_NAME,cv,SqlHelper.AUTHOR+" = ?",String[]{titleEt.getText().toString()});
        Toast.makeText(this, "修改成功：" , Toast.LENGTH_SHORT).show();
    }
    public String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date date = new Date();
        String str = sdf.format(date);
        return str;
    }
}
*/