package com.example.allprojects;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.allprojects.Diary.Diary;
import com.example.allprojects.Gweather.WeatherMainActivity;


public class MainActivity extends AppCompatActivity {
    Button btn1;
    Button btn2;
    Button btn5;
    Button btn3;
    Button btn4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //控件实际化
        btn1 = (Button) findViewById(R.id.Cululater);
        btn2 = (Button) findViewById(R.id.Diary);
        btn3 = (Button) findViewById(R.id.Weather);
        btn4 = (Button) findViewById(R.id.Music);
        btn5 = (Button) findViewById(R.id.Exit);
        setContentView(R.layout.activity_main);
        ToCalculater();
        ToDiary();
        ToWeather();
        kILL();
        //待开发部分 天气预报＋音乐播放器
        /* btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent是一种运行时绑定（run-time binding）机制，它能在程序运行过程中连接两个不同的组件。
                //在存放资源代码的文件夹下下，
                Intent i = new Intent(MainActivity.this, Weather.class);
                startActivity(i);//启动
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent是一种运行时绑定（run-time binding）机制，它能在程序运行过程中连接两个不同的组件。
                //在存放资源代码的文件夹下下，
                Intent i = new Intent(MainActivity.this, Music.class);
                startActivity(i);//启动
            }
        });*/

    }
    public void ToCalculater(){
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Calculator.class);
                startActivity(intent);
                finish();
            }
        });
    }
    public void ToDiary(){
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Diary.class);
                startActivity(intent);
                finish();
            }
        });
    }
    public void ToWeather(){
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent是一种运行时绑定（run-time binding）机制，它能在程序运行过程中连接两个不同的组件。
                //在存放资源代码的文件夹下下，
                Intent i = new Intent(MainActivity.this, WeatherMainActivity.class);
                startActivity(i);//启动
            }
        });
    }

    public void kILL(){
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                android.os.Process.killProcess(android.os.Process.myPid());//exit
            }
        });

    }

}