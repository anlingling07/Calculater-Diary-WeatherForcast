package com.example.allprojects.Diary;


import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.allprojects.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ShowDiary extends AppCompatActivity {
    private TextView mEt;
    private TextView mtitleEt;
    private TextView mauthorEt;
    private TextView time;
    private SqlHelper mDb;
    private SQLiteDatabase mSql;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary_show);
        mEt = (TextView)this.findViewById(R.id.showtext);
        mtitleEt=(TextView)this.findViewById(R.id.showtitle);
        mauthorEt=(TextView)this.findViewById(R.id.showauthor);
        time = (TextView)this.findViewById(R.id.showtime);
        mDb = new SqlHelper(this);
        mSql = mDb.getWritableDatabase();
        mEt.setText(getIntent().getStringExtra(SqlHelper.CONTENT));
        mtitleEt.setText(getIntent().getStringExtra(SqlHelper.TITLE));
        mauthorEt.setText(getIntent().getStringExtra(SqlHelper.AUTHOR));
        time.setText(getIntent().getStringExtra(SqlHelper.TIME));
    }
    public void delete(View v) {
        int id = getIntent().getIntExtra(SqlHelper.ID,0);
        mSql.delete(SqlHelper.TABLE_NAME," _id = " + id,null);
        finish();

    }
    public void goBack(View v) {
        finish();
    }

   /* public void edit(View v){
        ContentValues cv = new ContentValues();
        cv.put(SqlHelper.CONTENT,mEt.getText().toString());
        cv.put(SqlHelper.TIME,getTime());
        mSql.update(SqlHelper.TABLE_NAME,null,cv);
    }
    public String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");//获得时间
        Date date = new Date();
        String str = sdf.format(date);
        return str;
    }*/
}