package com.example.allprojects.Diary;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.allprojects.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddDIary extends AppCompatActivity {
    private EditText mEt;
    private EditText titleEt;
    private EditText authorEt;
    private SqlHelper mDb;
    private SQLiteDatabase mSqldb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary_add);
        mEt = (EditText) this.findViewById(R.id.text);
        titleEt=(EditText)this.findViewById(R.id.title);
        authorEt=(EditText)this.findViewById(R.id.author);
        mDb = new SqlHelper(this);
        mSqldb = mDb.getWritableDatabase();
    }
    public void save(View v) {

        DbAdd();
        finish();
    }
    public void cancle(View v) {
        mEt.setText("");
        titleEt.setText("");
        authorEt.setText("");
        finish();
    }
    public void DbAdd() {
        //将基础数据存储在cv中
        ContentValues cv = new ContentValues();
        cv.put(SqlHelper.TITLE,titleEt.getText().toString());
        cv.put(SqlHelper.TIME,getTime());
        cv.put(SqlHelper.CONTENT,mEt.getText().toString());
        cv.put(SqlHelper.AUTHOR,authorEt.getText().toString());
        mSqldb.insert(SqlHelper.TABLE_NAME,null,cv);
    }
    public String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date date = new Date();
        String str = sdf.format(date);
        return str;
    }
}
