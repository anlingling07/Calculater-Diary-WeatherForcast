package com.example.allprojects.Gweather;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.allprojects.R;

import java.util.List;

public class CityAdapter extends BaseAdapter {
    //
    class ViewHolder{
        TextView TVcityName;
        //删除城市
        ImageView ivDelCity;
        //选择城市后返回天气界面

    }
    private List<CityItem> list;

    public CityAdapter(List<CityItem> list){
        this.list=list;
    }
    @Override
    public View getView(final int position, View covertView, final ViewGroup viewGroup) {
        View view;
        ViewHolder viewHolder;
        if(covertView==null){
            view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gweather_city_item,viewGroup,false);
            viewHolder=new ViewHolder();
            viewHolder.TVcityName=view.findViewById(R.id.tv_city_name);

            viewHolder.ivDelCity=view.findViewById(R.id.iv_del_city);
            //将viewHolder存入在view中
            view.setTag(viewHolder);
        }else{
            view=covertView;
            viewHolder= (ViewHolder) view.getTag();
        }

        CityItem cityItem= list.get(position);
        viewHolder.TVcityName.setText(cityItem.getCityName());

        //删除城市
        viewHolder.ivDelCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.remove(position);
                notifyDataSetChanged();//本身就是adapter
            }
        });


        return view;
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

}
